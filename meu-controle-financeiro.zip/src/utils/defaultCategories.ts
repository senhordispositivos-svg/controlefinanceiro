import { Category } from '../types';

export const DEFAULT_CATEGORIES: Omit<Category, 'id'>[] = [
  { userId: 'system', name: 'Alimentação', icon: 'Utensils', color: '#10B981', isDefault: true },
  { userId: 'system', name: 'Moradia', icon: 'Home', color: '#3B82F6', isDefault: true },
  { userId: 'system', name: 'Energia', icon: 'Zap', color: '#F59E0B', isDefault: true },
  { userId: 'system', name: 'Água', icon: 'Droplets', color: '#06B6D4', isDefault: true },
  { userId: 'system', name: 'Internet', icon: 'Wifi', color: '#6366F1', isDefault: true },
  { userId: 'system', name: 'Telefone', icon: 'Phone', color: '#8B5CF6', isDefault: true },
  { userId: 'system', name: 'Transporte', icon: 'Bus', color: '#EC4899', isDefault: true },
  { userId: 'system', name: 'Combustível', icon: 'Fuel', color: '#EF4444', isDefault: true },
  { userId: 'system', name: 'Saúde', icon: 'HeartPulse', color: '#14B8A6', isDefault: true },
  { userId: 'system', name: 'Educação', icon: 'GraduationCap', color: '#84CC16', isDefault: true },
  { userId: 'system', name: 'Lazer', icon: 'Gamepad2', color: '#F97316', isDefault: true },
  { userId: 'system', name: 'Compras', icon: 'ShoppingBag', color: '#D946EF', isDefault: true },
  { userId: 'system', name: 'Assinaturas', icon: 'Tv', color: '#A855F7', isDefault: true },
  { userId: 'system', name: 'Impostos', icon: 'FileText', color: '#64748B', isDefault: true },
  { userId: 'system', name: 'Seguros', icon: 'ShieldCheck', color: '#0EA5E9', isDefault: true },
  { userId: 'system', name: 'Cartão de Crédito', icon: 'CreditCard', color: '#4F46E5', isDefault: true },
  { userId: 'system', name: 'Pix', icon: 'Send', color: '#059669', isDefault: true },
  { userId: 'system', name: 'Boleto', icon: 'Barcode', color: '#78716C', isDefault: true },
  { userId: 'system', name: 'Outros', icon: 'MoreHorizontal', color: '#94A3B8', isDefault: true },
];

export const INCOME_ORIGINS = [
  'Salário',
  'Freelance',
  'Hora extra',
  'Venda',
  'Serviço',
  'Comissão',
  'Investimentos',
  'Aluguel Recebido',
  '13º Salário',
  'Férias',
  'Restituição IR',
  'Outros',
];
